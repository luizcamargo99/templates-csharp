﻿using System;

namespace $rootnamespace$
{
    public class $safeitemname$
    {
        public $safeitemname$()
        {

        }

        public void Action ()
        {

        }
    }
}
